import json, requests, os
from bs4 import BeautifulSoup
import urllib

                                app_api = ClarifaiApp(api_key='a53895dff8c441b7b998b73961fc219d')
                                model = app_api.models.get('food')
                                model.model_version = 'a53895dff8c441b7b998b73961fc219d'
                                image = ClImage(file_obj=open(UPLOAD_FOLDER+filename,'rb'))
                                predict_json = model.predict([image])
                                outputs = predict_json["outputs"]
                                concepts = outputs[0]['data']['concepts']
                                result_web = []
                                result_get = []
                                num = 0
                                for i in concepts:
                                    result_get.insert(num, i['name'])
                                    result_web.insert(num, i['name'] + str(round(i['value'] * 100, 2)) + '%')
                                    num += 1
 #Insert DB
                                r = Record(
                                    time=datetime.now(),
                                    tag=result_get[0],
                                    filepath=url_for('static', filename= 'uploaded_files/'+filename)
                                )




